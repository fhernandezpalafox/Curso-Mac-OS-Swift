//: Playground - noun: a place where people can play

import UIKit

var arreglo = [8,3,5,2,7,9,1]

arreglo.sort()

arreglo


// vs
var arregloLetras = ["a","x","c","b","z","y"]

arregloLetras.sort()

arregloLetras
