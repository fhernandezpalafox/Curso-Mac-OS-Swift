//: Playground - noun: a place where people can play

import UIKit

//TIPOS DE DATOS


//Enteros -> Int

var edad : Int = 27

let lustro : Int = 5

var  resultado : Int = edad / lustro

// +, - , * , /

//Flotantes -> Float  32 bits

//Double -> Double  64 bits


//calcular la longitud de una rueda de 90 cm de diametro
//Tip: L = d * Pi


var longitud : Double = 0

var d : Double = 90

let pi : Double = 3.1415

//resultado
longitud = d * pi



//Cadenas -> String
var numeroPerros : Int = 2

var cadenaCaracteres : String = "Mi nombre es Felipe y tengo \(numeroPerros)"

var cadenaCaracteres2 : String = "perros"

var cadenacaracteres3 : String = cadenaCaracteres + " " + cadenaCaracteres2


//Arreglos -> Array
var ejemploArray:[String] = ["Arroz","Pescado","Cebolla","Aceite"]

//Boleanos -> Bool

//Tuplas, Optionals, Color, Url ... etc etc













