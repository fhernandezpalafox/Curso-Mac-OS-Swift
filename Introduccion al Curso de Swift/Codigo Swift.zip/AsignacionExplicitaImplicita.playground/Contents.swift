//: Playground - noun: a place where people can play

import UIKit

//asignacion implicita y explicita


//implicita
var cadenaString = "Soy un string"
var numeroEntero  = 15

//explicita
var cadenaString2 : String = "Soy un string"
var numeroEntero2 : Int = 16


var resultado =  numeroEntero2 + 5



var 😃 = 10

var num = 2

var res = 😃 + num









