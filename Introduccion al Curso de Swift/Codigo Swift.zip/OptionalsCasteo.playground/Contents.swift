//: Playground - noun: a place where people can play

import UIKit

//introduccion  a casteo de tipo y a los optionals

var numeroEntero : Int = 24

var numeroString : String = ""

//tryParse(3,)
var i  = Int(numeroString)

print(Int(numeroString))

var suma : Int = Int(numeroString)! + numeroEntero

var sumaString : String = String(suma)
