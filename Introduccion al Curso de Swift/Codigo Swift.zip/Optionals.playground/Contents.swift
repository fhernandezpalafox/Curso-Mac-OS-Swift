//: Playground - noun: a place where people can play

import UIKit

//public void sumar(int dato=null){
//if(dato != null)
//    return dato + 2;
//else
//     return 2;
//}

//sumar();
//sumar(2);

//el signo de interrogacion va ser nil o null
var xOptional : Int?

//xOptional = 15

var y : Int = 10

print(xOptional)

//var suma = xOptional! + y



if let suma2 = xOptional {
    print("El resultado es "+String(suma2 + y))
}else
{
    print("Error")
}
















