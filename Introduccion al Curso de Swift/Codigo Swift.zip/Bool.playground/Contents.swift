//: Playground - noun: a place where people can play

import UIKit

let boleanoTrue:Bool = true

let boleanoFalse = false


var msg = ""

if boleanoTrue {

  print("Hola Mundo")
  msg  = "Hola Mundo"
    
}else
{
  print("No Cumple")
    msg  = "No Cumple"
    
}

print(msg)





