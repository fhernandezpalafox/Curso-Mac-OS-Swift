//: Playground - noun: a place where people can play

import UIKit

var propiedadCompu:Int {

    let x = 2
    let y = 2
    let resultado = x * y
    
    return  resultado
    
}

var num1  = 10

var res =  propiedadCompu + num1

propiedadCompu
