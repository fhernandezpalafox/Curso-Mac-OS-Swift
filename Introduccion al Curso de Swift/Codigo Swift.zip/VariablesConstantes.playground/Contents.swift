//: Playground - noun: a place where people can play

import UIKit

//variables
var variable = "Puedo cambiar"

//constantes
let constante  = "Nunca cambio"


variable = "otro valor"


//saldria error al asignar lun nuevo dato a una constante
//constante  = "volver a cambiar"


